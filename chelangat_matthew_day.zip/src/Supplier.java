/**
 * CSC 1102 Practical Exam Project - Group 26
 * Supplier: represents a company or person that supplies products to the store.
 */
public class Supplier {

    // Attributes are private (encapsulation); access is through getters/setters
    private String supplierId;
    private String name;
    private String phone;
    private String email;

    // Constructor
    public Supplier(String supplierId, String name, String phone, String email) {
        this.supplierId = supplierId;
        this.name = name;
        this.phone = phone;
        this.email = email;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return name;
    }
}
