/**
 * CSC 1102 Practical Exam Project - Group 26
 * Inventory: stores and manages all products and suppliers using arrays.
 * It contains the main business logic; the GUI only calls its methods.
 */
public class Inventory {

    private Product[] products;
    private int productCount;
    private Supplier[] suppliers;
    private int supplierCount;

    private int nextProductNumber = 1;
    private int nextSupplierNumber = 1;

    public Inventory() {
        products = new Product[10];   // starting capacity; grows when full
        suppliers = new Supplier[5];
        productCount = 0;
        supplierCount = 0;
    }

    // ======================= SUPPLIERS =======================

    public Supplier addSupplier(String name, String phone, String email) {
        if (supplierCount == suppliers.length) {
            growSupplierArray();
        }
        String id = String.format("S%03d", nextSupplierNumber);
        nextSupplierNumber++;
        Supplier s = new Supplier(id, name, phone, email);
        suppliers[supplierCount] = s;
        supplierCount++;
        return s;
    }

    private void growSupplierArray() {
        Supplier[] bigger = new Supplier[suppliers.length * 2];
        for (int i = 0; i < supplierCount; i++) {
            bigger[i] = suppliers[i];
        }
        suppliers = bigger;
    }

    public int getSupplierCount() {
        return supplierCount;
    }

    public Supplier getSupplierAt(int index) {
        if (index >= 0 && index < supplierCount) {
            return suppliers[index];
        }
        return null;
    }

    /** Counts how many products are supplied by the given supplier. */
    public int countProductsBySupplier(Supplier s) {
        int count = 0;
        for (int i = 0; i < productCount; i++) {
            if (products[i].getSupplier() == s) {
                count++;
            }
        }
        return count;
    }

    // ======================= PRODUCTS =======================

    /** Adds a product to the array and gives it a unique ID. */
    public Product addProduct(Product p) {
        if (productCount == products.length) {
            growProductArray();
        }
        p.setProductId(generateProductId());
        products[productCount] = p;
        productCount++;
        return p;
    }

    /** Generates IDs like P001, P002... and repeats until the ID is not already used. */
    private String generateProductId() {
        String id;
        do {
            id = String.format("P%03d", nextProductNumber);
            nextProductNumber++;
        } while (findProductIndex(id) != -1);
        return id;
    }

    /** Creates a bigger array and copies the existing products across. */
    private void growProductArray() {
        Product[] bigger = new Product[products.length * 2];
        for (int i = 0; i < productCount; i++) {
            bigger[i] = products[i];
        }
        products = bigger;
    }

    /** Linear search by ID. Returns the index, or -1 if not found. */
    public int findProductIndex(String id) {
        int i = 0;
        while (i < productCount) {
            if (products[i].getProductId().equalsIgnoreCase(id)) {
                return i;
            }
            i++;
        }
        return -1;
    }

    public Product findProduct(String id) {
        int index = findProductIndex(id);
        if (index == -1) {
            return null;
        }
        return products[index];
    }

    /** Copies the details of 'updated' into the stored product with the given ID. */
    public boolean updateProduct(String id, Product updated) {
        Product existing = findProduct(id);
        if (existing == null) {
            return false;
        }
        existing.setName(updated.getName());
        existing.setCategory(updated.getCategory());
        existing.setQuantity(updated.getQuantity());
        existing.setPrice(updated.getPrice());
        existing.setReorderLevel(updated.getReorderLevel());
        existing.setSupplier(updated.getSupplier());
        return true;
    }

    /** Removes a product and shifts the later products one place to the left. */
    public boolean deleteProduct(String id) {
        int index = findProductIndex(id);
        if (index == -1) {
            return false;
        }
        for (int i = index; i < productCount - 1; i++) {
            products[i] = products[i + 1];
        }
        products[productCount - 1] = null;
        productCount--;
        return true;
    }

    public boolean restock(String id, int amount) {
        Product p = findProduct(id);
        if (p == null) {
            return false;
        }
        return p.addStock(amount);
    }

    public boolean sell(String id, int amount) {
        Product p = findProduct(id);
        if (p == null) {
            return false;
        }
        return p.removeStock(amount);
    }

    public int getProductCount() {
        return productCount;
    }

    /** Returns a right-sized array containing every product. */
    public Product[] getAllProducts() {
        Product[] result = new Product[productCount];
        for (int i = 0; i < productCount; i++) {
            result[i] = products[i];
        }
        return result;
    }

    /**
     * Searches products. 'searchBy' is "ID", "Name" or "Category";
     * matching is case-insensitive and partial.
     */
    public Product[] search(String searchBy, String keyword) {
        String key = keyword.trim().toLowerCase();
        Product[] temp = new Product[productCount];
        int found = 0;

        for (int i = 0; i < productCount; i++) {
            String field;
            switch (searchBy) {
                case "ID":
                    field = products[i].getProductId();
                    break;
                case "Name":
                    field = products[i].getName();
                    break;
                case "Category":
                    field = products[i].getCategory();
                    break;
                default:
                    field = products[i].getName();
                    break;
            }
            if (field.toLowerCase().contains(key)) {
                temp[found] = products[i];
                found++;
            }
        }
        return trim(temp, found);
    }

    /** Returns only the products that are at or below their reorder level. */
    public Product[] getLowStockProducts() {
        Product[] temp = new Product[productCount];
        int found = 0;
        for (int i = 0; i < productCount; i++) {
            if (products[i].isLowStock()) {
                temp[found] = products[i];
                found++;
            }
        }
        return trim(temp, found);
    }

    private Product[] trim(Product[] temp, int size) {
        Product[] result = new Product[size];
        for (int i = 0; i < size; i++) {
            result[i] = temp[i];
        }
        return result;
    }

    // ======================= SUMMARY FIGURES =======================

    public int getTotalUnits() {
        int total = 0;
        for (int i = 0; i < productCount; i++) {
            total += products[i].getQuantity();
        }
        return total;
    }

    public double getTotalValue() {
        double total = 0;
        for (int i = 0; i < productCount; i++) {
            total += products[i].getTotalValue();
        }
        return total;
    }

    /** Adds a few example suppliers and products so the program is easy to demonstrate. */
    public void loadSampleData() {
        Supplier s1 = addSupplier("Kampala Wholesalers", "0701 111 222", "sales@kampalawholesale.ug");
        Supplier s2 = addSupplier("Nile Stationers", "0772 333 444", "info@nilestationers.ug");
        Supplier s3 = addSupplier("TechHub Uganda", "0753 555 666", "orders@techhub.ug");

        addProduct(new Product("Rice (5kg bag)", "Groceries", 40, 22000, 10, s1));
        addProduct(new Product("Cooking Oil (3L)", "Groceries", 8, 18500, 10, s1));
        addProduct(new Product("Exercise Book (96pg)", "Stationery", 120, 1500, 30, s2));
        addProduct(new Product("Ballpoint Pens (box)", "Stationery", 15, 6000, 20, s2));
        addProduct(new Product("USB Flash Drive 32GB", "Electronics", 25, 35000, 5, s3));
        addProduct(new Product("Wireless Mouse", "Electronics", 0, 45000, 5, s3));
    }
}
