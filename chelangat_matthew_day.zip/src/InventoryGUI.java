import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * CSC 1102 Practical Exam Project - Group 26
 * InventoryGUI: the Swing window. It has three tabs (Products, Suppliers, Summary)
 * and passes all user actions to the Inventory object.
 */
public class InventoryGUI extends JFrame {

    private Inventory inventory;
    private Product[] displayed = new Product[0];   // products currently shown in the table

    // ---- Products tab components ----
    private JTextField txtName, txtCategory, txtQuantity, txtPrice, txtReorder;
    private JComboBox<String> cmbSupplier;
    private JComboBox<String> cmbSearchBy;
    private JTextField txtSearch, txtStockAmount;
    private JTable productTable;
    private DefaultTableModel productModel;

    // ---- Suppliers tab components ----
    private JTextField txtSupName, txtSupPhone, txtSupEmail;
    private DefaultTableModel supplierModel;

    // ---- Summary tab components ----
    private JLabel lblTotalProducts, lblTotalUnits, lblTotalValue, lblLowStock;
    private DefaultTableModel lowStockModel;

    private JLabel statusBar;
    private JTabbedPane tabs;

    public InventoryGUI(Inventory inventory) {
        super("Inventory Management System - Group 26");
        this.inventory = inventory;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(980, 640);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        tabs = new JTabbedPane();
        tabs.addTab("Products", buildProductsTab());
        tabs.addTab("Suppliers", buildSuppliersTab());
        tabs.addTab("Summary & Low Stock", buildSummaryTab());
        tabs.addChangeListener(new javax.swing.event.ChangeListener() {
            @Override
            public void stateChanged(javax.swing.event.ChangeEvent e) {
                refreshAll();
            }
        });
        add(tabs, BorderLayout.CENTER);

        statusBar = new JLabel(" Welcome! Select a product row to edit, restock or sell it.");
        statusBar.setBorder(BorderFactory.createEtchedBorder());
        add(statusBar, BorderLayout.SOUTH);

        refreshAll();
    }

    public JTabbedPane getTabs() {
        return tabs;
    }

    // ===================================================================
    //  PRODUCTS TAB
    // ===================================================================
    private JPanel buildProductsTab() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        // ----- top: form, buttons, search -----
        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));

        JPanel form = new JPanel(new GridLayout(2, 6, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Product details"));
        txtName = new JTextField();
        txtCategory = new JTextField();
        txtQuantity = new JTextField();
        txtPrice = new JTextField();
        txtReorder = new JTextField();
        cmbSupplier = new JComboBox<String>();
        form.add(new JLabel("Name:"));
        form.add(txtName);
        form.add(new JLabel("Category:"));
        form.add(txtCategory);
        form.add(new JLabel("Quantity:"));
        form.add(txtQuantity);
        form.add(new JLabel("Unit price (UGX):"));
        form.add(txtPrice);
        form.add(new JLabel("Reorder level:"));
        form.add(txtReorder);
        form.add(new JLabel("Supplier:"));
        form.add(cmbSupplier);
        top.add(form);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        JButton btnAdd = new JButton("Add Product");
        JButton btnUpdate = new JButton("Update Selected");
        JButton btnDelete = new JButton("Delete Selected");
        JButton btnClear = new JButton("Clear Form");
        buttons.add(btnAdd);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnClear);
        top.add(buttons);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search"));
        cmbSearchBy = new JComboBox<String>(new String[]{"Name", "Category", "ID"});
        txtSearch = new JTextField(18);
        JButton btnSearch = new JButton("Search");
        JButton btnShowAll = new JButton("Show All");
        searchPanel.add(new JLabel("Search by:"));
        searchPanel.add(cmbSearchBy);
        searchPanel.add(txtSearch);
        searchPanel.add(btnSearch);
        searchPanel.add(btnShowAll);
        top.add(searchPanel);

        panel.add(top, BorderLayout.NORTH);

        // ----- centre: table -----
        String[] columns = {"ID", "Name", "Category", "Qty", "Unit Price (UGX)", "Reorder Lvl", "Supplier", "Status"};
        productModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;   // the table is read-only; editing is done through the form
            }
        };
        productTable = new JTable(productModel);
        productTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        productTable.setRowHeight(22);
        productTable.getColumnModel().getColumn(7).setCellRenderer(new StatusRenderer());
        productTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    fillFormFromSelection();
                }
            }
        });
        panel.add(new JScrollPane(productTable), BorderLayout.CENTER);

        // ----- bottom: stock operations -----
        JPanel stock = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        stock.setBorder(BorderFactory.createTitledBorder("Stock operations (for the selected product)"));
        txtStockAmount = new JTextField(8);
        JButton btnRestock = new JButton("Restock (add stock)");
        JButton btnSell = new JButton("Sell / Issue (remove stock)");
        stock.add(new JLabel("Amount:"));
        stock.add(txtStockAmount);
        stock.add(btnRestock);
        stock.add(btnSell);
        panel.add(stock, BorderLayout.SOUTH);

        // ----- button actions -----
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { addProduct(); }
        });
        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { updateProduct(); }
        });
        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { deleteProduct(); }
        });
        btnClear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { clearProductForm(); }
        });
        btnSearch.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { searchProducts(); }
        });
        btnShowAll.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                txtSearch.setText("");
                refreshProductTable(inventory.getAllProducts());
                setStatus("Showing all " + inventory.getProductCount() + " products.");
            }
        });
        btnRestock.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { changeStock(true); }
        });
        btnSell.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { changeStock(false); }
        });

        return panel;
    }

    /** Colours the Status column: red = out of stock, orange = low stock, green = in stock. */
    private class StatusRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (!isSelected) {
                String status = String.valueOf(value);
                if (status.equals("Out of Stock")) {
                    c.setBackground(new Color(248, 200, 200));
                } else if (status.equals("Low Stock")) {
                    c.setBackground(new Color(255, 230, 170));
                } else {
                    c.setBackground(new Color(205, 235, 205));
                }
                c.setForeground(Color.BLACK);
            }
            return c;
        }
    }

    // ---------------- product actions ----------------

    /** Reads the form and builds a Product. Returns null (after showing a message) if the input is invalid. */
    private Product buildProductFromForm() {
        String name = txtName.getText().trim();
        String category = txtCategory.getText().trim();
        if (name.isEmpty() || category.isEmpty()) {
            showError("Please enter both a name and a category.");
            return null;
        }
        try {
            int quantity = Integer.parseInt(txtQuantity.getText().trim());
            double price = Double.parseDouble(txtPrice.getText().trim());
            int reorder = Integer.parseInt(txtReorder.getText().trim());
            if (quantity < 0 || price < 0 || reorder < 0) {
                showError("Quantity, price and reorder level cannot be negative.");
                return null;
            }
            // Index 0 of the combo box is "None", so supplier number = index - 1
            Supplier supplier = inventory.getSupplierAt(cmbSupplier.getSelectedIndex() - 1);
            return new Product(name, category, quantity, price, reorder, supplier);
        } catch (NumberFormatException ex) {
            showError("Quantity, unit price and reorder level must be valid numbers.");
            return null;
        }
    }

    private void addProduct() {
        Product p = buildProductFromForm();
        if (p != null) {
            inventory.addProduct(p);
            refreshAll();
            clearProductForm();
            setStatus("Added " + p.getName() + " with ID " + p.getProductId() + ".");
        }
    }

    private Product getSelectedProduct() {
        int row = productTable.getSelectedRow();
        if (row >= 0 && row < displayed.length) {
            return displayed[row];
        }
        return null;
    }

    private void updateProduct() {
        Product selected = getSelectedProduct();
        if (selected == null) {
            showError("Select a product in the table first.");
            return;
        }
        Product updated = buildProductFromForm();
        if (updated != null) {
            inventory.updateProduct(selected.getProductId(), updated);
            refreshAll();
            setStatus("Updated " + selected.getProductId() + ".");
        }
    }

    private void deleteProduct() {
        Product selected = getSelectedProduct();
        if (selected == null) {
            showError("Select a product in the table first.");
            return;
        }
        int choice = JOptionPane.showConfirmDialog(this,
                "Delete " + selected.getName() + " (" + selected.getProductId() + ")?",
                "Confirm delete", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            inventory.deleteProduct(selected.getProductId());
            refreshAll();
            clearProductForm();
            setStatus("Deleted " + selected.getName() + ".");
        }
    }

    private void searchProducts() {
        String keyword = txtSearch.getText().trim();
        if (keyword.isEmpty()) {
            showError("Type something to search for.");
            return;
        }
        String searchBy = (String) cmbSearchBy.getSelectedItem();
        Product[] results = inventory.search(searchBy, keyword);
        refreshProductTable(results);
        setStatus(results.length + " product(s) found for \"" + keyword + "\" (by " + searchBy + ").");
    }

    /** Handles both buttons: restock = true adds stock, restock = false removes stock. */
    private void changeStock(boolean restock) {
        Product selected = getSelectedProduct();
        if (selected == null) {
            showError("Select a product in the table first.");
            return;
        }
        int amount;
        try {
            amount = Integer.parseInt(txtStockAmount.getText().trim());
        } catch (NumberFormatException ex) {
            showError("Enter a whole number for the amount.");
            return;
        }
        if (amount <= 0) {
            showError("The amount must be greater than zero.");
            return;
        }

        String id = selected.getProductId();
        if (restock) {
            inventory.restock(id, amount);
            setStatus("Added " + amount + " units to " + selected.getName() + ".");
        } else {
            if (!inventory.sell(id, amount)) {
                showError("Not enough stock. Only " + selected.getQuantity() + " unit(s) of "
                        + selected.getName() + " available.");
                return;
            }
            String msg = "Sold " + amount + " unit(s) of " + selected.getName() + ".";
            if (selected.isLowStock()) {
                msg += "  WARNING: stock is now low (" + selected.getQuantity() + " left).";
            }
            setStatus(msg);
        }
        txtStockAmount.setText("");
        refreshAll();
    }

    private void fillFormFromSelection() {
        Product p = getSelectedProduct();
        if (p == null) {
            return;
        }
        txtName.setText(p.getName());
        txtCategory.setText(p.getCategory());
        txtQuantity.setText(String.valueOf(p.getQuantity()));
        txtPrice.setText(String.valueOf((long) p.getPrice()));
        txtReorder.setText(String.valueOf(p.getReorderLevel()));

        int comboIndex = 0;   // 0 = "None"
        for (int i = 0; i < inventory.getSupplierCount(); i++) {
            if (inventory.getSupplierAt(i) == p.getSupplier()) {
                comboIndex = i + 1;
            }
        }
        cmbSupplier.setSelectedIndex(comboIndex);
    }

    private void clearProductForm() {
        txtName.setText("");
        txtCategory.setText("");
        txtQuantity.setText("");
        txtPrice.setText("");
        txtReorder.setText("");
        cmbSupplier.setSelectedIndex(0);
        productTable.clearSelection();
    }

    // ===================================================================
    //  SUPPLIERS TAB
    // ===================================================================
    private JPanel buildSuppliersTab() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        form.setBorder(BorderFactory.createTitledBorder("Register a new supplier"));
        txtSupName = new JTextField(16);
        txtSupPhone = new JTextField(12);
        txtSupEmail = new JTextField(18);
        JButton btnAddSupplier = new JButton("Add Supplier");
        form.add(new JLabel("Name:"));
        form.add(txtSupName);
        form.add(new JLabel("Phone:"));
        form.add(txtSupPhone);
        form.add(new JLabel("Email:"));
        form.add(txtSupEmail);
        form.add(btnAddSupplier);
        panel.add(form, BorderLayout.NORTH);

        String[] columns = {"ID", "Name", "Phone", "Email", "Products Supplied"};
        supplierModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable supplierTable = new JTable(supplierModel);
        supplierTable.setRowHeight(22);
        panel.add(new JScrollPane(supplierTable), BorderLayout.CENTER);

        btnAddSupplier.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = txtSupName.getText().trim();
                String phone = txtSupPhone.getText().trim();
                String email = txtSupEmail.getText().trim();
                if (name.isEmpty() || phone.isEmpty()) {
                    showError("A supplier needs at least a name and a phone number.");
                    return;
                }
                Supplier s = inventory.addSupplier(name, phone, email);
                txtSupName.setText("");
                txtSupPhone.setText("");
                txtSupEmail.setText("");
                refreshAll();
                setStatus("Added supplier " + s.getName() + " (" + s.getSupplierId() + ").");
            }
        });

        return panel;
    }

    // ===================================================================
    //  SUMMARY TAB
    // ===================================================================
    private JPanel buildSummaryTab() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel figures = new JPanel(new GridLayout(1, 4, 10, 10));
        figures.setBorder(BorderFactory.createTitledBorder("Inventory summary"));
        lblTotalProducts = makeFigureLabel();
        lblTotalUnits = makeFigureLabel();
        lblTotalValue = makeFigureLabel();
        lblLowStock = makeFigureLabel();
        figures.add(lblTotalProducts);
        figures.add(lblTotalUnits);
        figures.add(lblTotalValue);
        figures.add(lblLowStock);
        panel.add(figures, BorderLayout.NORTH);

        String[] columns = {"ID", "Name", "Category", "Qty", "Reorder Lvl", "Supplier", "Status"};
        lowStockModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable lowStockTable = new JTable(lowStockModel);
        lowStockTable.setRowHeight(22);
        lowStockTable.getColumnModel().getColumn(6).setCellRenderer(new StatusRenderer());
        JScrollPane scroll = new JScrollPane(lowStockTable);
        scroll.setBorder(BorderFactory.createTitledBorder("Products that need restocking"));
        panel.add(scroll, BorderLayout.CENTER);

        return panel;
    }

    private JLabel makeFigureLabel() {
        JLabel label = new JLabel("", SwingConstants.CENTER);
        label.setFont(label.getFont().deriveFont(Font.BOLD, 14f));
        return label;
    }

    // ===================================================================
    //  REFRESH HELPERS
    // ===================================================================
    private void refreshAll() {
        refreshSupplierCombo();
        refreshProductTable(inventory.getAllProducts());
        refreshSupplierTable();
        refreshSummary();
    }

    private void refreshProductTable(Product[] list) {
        displayed = list;
        productModel.setRowCount(0);
        for (int i = 0; i < list.length; i++) {
            Product p = list[i];
            productModel.addRow(new Object[]{
                    p.getProductId(), p.getName(), p.getCategory(), p.getQuantity(),
                    formatMoney(p.getPrice()), p.getReorderLevel(), p.getSupplierName(), p.getStatus()
            });
        }
    }

    private void refreshSupplierCombo() {
        int previous = cmbSupplier.getSelectedIndex();
        cmbSupplier.removeAllItems();
        cmbSupplier.addItem("None");
        for (int i = 0; i < inventory.getSupplierCount(); i++) {
            cmbSupplier.addItem(inventory.getSupplierAt(i).getName());
        }
        if (previous >= 0 && previous < cmbSupplier.getItemCount()) {
            cmbSupplier.setSelectedIndex(previous);
        }
    }

    private void refreshSupplierTable() {
        supplierModel.setRowCount(0);
        for (int i = 0; i < inventory.getSupplierCount(); i++) {
            Supplier s = inventory.getSupplierAt(i);
            supplierModel.addRow(new Object[]{
                    s.getSupplierId(), s.getName(), s.getPhone(), s.getEmail(),
                    inventory.countProductsBySupplier(s)
            });
        }
    }

    private void refreshSummary() {
        Product[] low = inventory.getLowStockProducts();
        lblTotalProducts.setText("<html><center>Products<br>" + inventory.getProductCount() + "</center></html>");
        lblTotalUnits.setText("<html><center>Total units<br>" + inventory.getTotalUnits() + "</center></html>");
        lblTotalValue.setText("<html><center>Stock value<br>UGX " + formatMoney(inventory.getTotalValue()) + "</center></html>");
        lblLowStock.setText("<html><center>Low / out of stock<br>" + low.length + "</center></html>");

        lowStockModel.setRowCount(0);
        for (int i = 0; i < low.length; i++) {
            Product p = low[i];
            lowStockModel.addRow(new Object[]{
                    p.getProductId(), p.getName(), p.getCategory(), p.getQuantity(),
                    p.getReorderLevel(), p.getSupplierName(), p.getStatus()
            });
        }
    }

    private String formatMoney(double amount) {
        return String.format("%,.0f", amount);
    }

    private void setStatus(String message) {
        statusBar.setText(" " + message);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Please check your input", JOptionPane.WARNING_MESSAGE);
    }
}
