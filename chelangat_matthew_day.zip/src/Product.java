/**
 * CSC 1102 Practical Exam Project - Group 26
 * Product: represents one item stocked in the inventory.
 */
public class Product {

    private String productId;
    private String name;
    private String category;
    private int quantity;
    private double price;        // unit price in UGX
    private int reorderLevel;    // stock level at or below which the item is "low"
    private Supplier supplier;   // may be null if no supplier is assigned

    // Main constructor
    public Product(String productId, String name, String category, int quantity,
                   double price, int reorderLevel, Supplier supplier) {
        this.productId = productId;
        this.name = name;
        this.category = category;
        this.quantity = quantity;
        this.price = price;
        this.reorderLevel = reorderLevel;
        this.supplier = supplier;
    }

    // Overloaded constructor: used when the ID will be generated later by the Inventory
    public Product(String name, String category, int quantity, double price,
                   int reorderLevel, Supplier supplier) {
        this("", name, category, quantity, price, reorderLevel, supplier);
    }

    // ---------- Getters and setters ----------
    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getReorderLevel() { return reorderLevel; }
    public void setReorderLevel(int reorderLevel) { this.reorderLevel = reorderLevel; }

    public Supplier getSupplier() { return supplier; }
    public void setSupplier(Supplier supplier) { this.supplier = supplier; }

    // ---------- Behaviour ----------

    /** Adds stock (restocking). Only positive amounts are accepted. */
    public boolean addStock(int amount) {
        if (amount > 0) {
            quantity += amount;
            return true;
        }
        return false;
    }

    /** Removes stock (a sale or issue). Fails if the amount is invalid or exceeds stock. */
    public boolean removeStock(int amount) {
        if (amount > 0 && amount <= quantity) {
            quantity -= amount;
            return true;
        }
        return false;
    }

    /** True when the quantity is at or below the reorder level. */
    public boolean isLowStock() {
        return quantity <= reorderLevel;
    }

    /** Value of the stock held for this product (quantity x unit price). */
    public double getTotalValue() {
        return quantity * price;
    }

    /** Text status shown in the tables. */
    public String getStatus() {
        if (quantity == 0) {
            return "Out of Stock";
        } else if (isLowStock()) {
            return "Low Stock";
        } else {
            return "In Stock";
        }
    }

    public String getSupplierName() {
        if (supplier == null) {
            return "None";
        }
        return supplier.getName();
    }

    @Override
    public String toString() {
        return productId + " - " + name + " (" + quantity + ")";
    }
}
