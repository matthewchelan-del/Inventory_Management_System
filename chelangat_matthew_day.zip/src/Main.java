/*
 * ====================================================================
 *  CSC 1102: Structured and Object-Oriented Programming
 *  Practical Exam Project - Inventory Management System
 * --------------------------------------------------------------------
 *  GROUP 26
 *  1. Chelangat Matthew  | Reg No: 26/U/0207       | Student No: 2600700207
 *  2. Twine Hakim        | Reg No: 26/U/03666/PS   | Student No: 2600703666
 *  3. Mabusi Zoe Charity | Reg No: 26/U/03558/PS   | Student No: 2600703558
 *  4. Kamya Elijah       | Reg No: 26/U/0303       | Student No: 2600700303
 *
 *  GitHub: https://github.com/matthewchelan-del/Inventory_Management_System.git
 * ====================================================================
 */
import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {
        // Create the data model and fill it with a few example records
        Inventory inventory = new Inventory();
        inventory.loadSampleData();

        // Build the GUI on the Swing event thread
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                InventoryGUI gui = new InventoryGUI(inventory);
                gui.setVisible(true);
            }
        });
    }
}
